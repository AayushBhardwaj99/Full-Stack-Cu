

const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
app.use(express.json());

const secret = 'jwtsecurekey';

function verifyToken(req, res, next) {
  const header = req.headers['authorization'];
  if (header && header.startsWith('Bearer ')) {
    const token = header.split(' ')[1];
    try {
      const decoded = jwt.verify(token, secret);
      req.user = decoded;
      next();
    } catch {
      res.status(401).json({ message: 'Invalid token' });
    }
  } else {
    res.status(401).json({ message: 'Token missing' });
  }
}

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'testuser' && password === 'password') {
    const token = jwt.sign({ username }, secret);
    res.json({ token });
  } else {
    res.status(403).json({ message: 'Invalid credentials' });
  }
});

app.get('/protected', verifyToken, (req, res) => {
  res.json({
    message: 'You have accessed a protected route.',
    user: { username: req.user.username }
  });
});

app.listen(3000);
