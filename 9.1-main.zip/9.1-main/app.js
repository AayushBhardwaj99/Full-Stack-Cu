import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🚀 Dockerized React App</h1>
      <p>This React app is running inside a Docker container using a multi-stage build!</p>
    </div>
  );
}

export default App;
